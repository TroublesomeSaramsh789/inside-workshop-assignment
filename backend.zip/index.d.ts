export interface InsertUserType {
  username: string;
  email: string;
  phone: string;
  password: string;
  userType: string;
}
